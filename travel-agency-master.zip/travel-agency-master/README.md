# Travel Agency with full ecommerce

### This site developed using PHP mysqli and some javascript. It has full ecommerce functionality.

#### How to import->
  1. create a database on your localhost named as `tagency` & then import the above mentioned sql file
  2. then clone the repo to your htdocs folder and visit using this URL on your localhost http://localhost/travel-agency/
  3. then import the sql (which is inside the sql directory) file on phpmyadmin


to access admin panel:
http://localhost/travel-agency/admin_area/


Email: admin@gmail.com
Password: admin



### Project Preview
![preview of travel agency](https://github.com/ashraf-kabir/travel-agency/blob/master/travel-agency-preview.PNG)



## Raise a star to support me.