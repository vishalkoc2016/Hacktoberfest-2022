<div>
    <h2 align="center">Pay now with Paypal:</h2>
    <p style="text-align: center;"><a href="https://www.paypal.com/us/home"><img src="../paypal.jpg" width="300" height="150"></a></p>
</div>